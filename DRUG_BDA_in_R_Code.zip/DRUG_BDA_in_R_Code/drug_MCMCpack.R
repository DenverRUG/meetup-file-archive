# Read data manually 
y <- c(4,5,4,1,0,4,3,4,0,6,3,3,4,0,2,6,3,3,5,4,5,3,1,4,4,1,5,5,3,4,2,5,2,2,3,4,2,1,3,2,2,
	1,1,1,1,3,0,0,1,0,1,1,0,0,3,1,0,3,2,2,0,1,1,1,0,1,0,1,0,0,0,2,1,0,0,0,1,1,0,2,3,3,1,
	1,2,1,1,1,1,2,4,2,0,0,0,1,4,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1)

# Do change point analysis using MCMCpack package
# Uses different priors, model formulations (see package details), but produces similar results

library(MCMCpack)

chain4 <- MCMCpoissonChange(y ~ 1, m = 1, c0 = 6.85, d0 = 1, marginal.likelihood = "Chib95")

# Summarize posterior
summary(chain4)

# Plot graph of possible change point.
plotChangepoint(chain4)