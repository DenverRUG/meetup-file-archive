library(coda)

# Should ideally run multiple chains with different starting values
chain5 <- gibbs.rcpp(nsimr = nsim, 
	yr = y, ar = 4, br = 1, cr = 1, dr = 2, kpossr = 1:112, 
	phir = 2, kr = 80)
chain6 <- gibbs.rcpp(nsimr = nsim, 
	yr = y, ar = 4, br = 1, cr = 1, dr = 2, kpossr = 1:112, 
	phir = 5, kr = 20)
	
# Combine chains into mcmc.list object

all.chains <- mcmc.list(mcmc(chain3), mcmc(chain5), mcmc(chain6))

# Calculate Gelman-Rubin statistic
# Want to see numbers less than 1.1
# Indicates whether chains have converged to same distribution
gelman.diag(all.chains)

# Plot Gelman-Rubin statistic over time
gelman.plot(all.chains)

# Calculate effective sample size
# How many "i.i.d" observations of each variable do we have
effectiveSize(all.chains)

# Trace plots/Sample path plots
# How to the values of the parameters change between iterations
# Want to see scribbly line
traceplot(all.chains)

# Combine all chains, throw away conservative burnin
mygibbs <- as.matrix(all.chains)[-(1:15000),]

# Determine how correlated successive samples values are for each parameters
# We don't want a lot of correlation after the first few lags.
acf(mygibbs[,1]) # variable 1
acf(mygibbs[,2]) # variable 2
acf(mygibbs[,3]) # variable 3

# Density plots
# What do your posterior distributions look like!
# Determine approximate density/mass function for each parameter
dlambda <- density(mygibbs[,1])
dphi <- density(mygibbs[,2])
dk <- table(mygibbs[,3])/nrow(mygibbs)

par(mfrow = c(2, 2))
# plot the approximate density/mass function for each parameter
plot(dlambda, xlab = "lambda", ylab = "density", main = "")
title("Posterior density for lambda")

plot(dphi, xlab = "phi", ylab = "density", main = "")
title("Posterior density for lambda")

myk <- as.numeric(names(dk))
plot(myk, dk, xlab = "k", ylab = "probability", type = "h")
title("Posterior density for lambda")

# There are many other diagnostics to run.

