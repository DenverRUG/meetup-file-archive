# Read data manually 
y <- c(4,5,4,1,0,4,3,4,0,6,3,3,4,0,2,6,3,3,5,4,5,3,1,4,4,1,5,5,3,4,2,5,2,2,3,4,2,1,3,2,2,
	1,1,1,1,3,0,0,1,0,1,1,0,0,3,1,0,3,2,2,0,1,1,1,0,1,0,1,0,0,0,2,1,0,0,0,1,1,0,2,3,3,1,
	1,2,1,1,1,1,2,4,2,0,0,0,1,4,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1)

# determine number of simulations
nsim <- 10000

# matrix to store simulated values from each cycle
out <- matrix(NA, nrow = nsim, ncol = 3)

#starting values for phi and k
phi <- 1
k <- 40

for(i in 1:nsim)
{
	# sample values of lambda and phi from full conditional distributions
	lambda <- rgamma(1, 4 + sum(y[1:k]), 1 + k)
	phi <- rgamma(1, 1 + sum(y[min((k+1),112):112]), 2 + 112 - k)

	# determine probability masses for full conditional of k
	upmf <- numeric(112)
	for(j in 1:112)
	{
		upmf[j] <- exp(j*(phi - lambda)) * (lambda/phi)^sum(y[1:j])
	}
	pmf <- upmf / sum(upmf)
	
	#sample value of k
	k <- sample(x = 1:112, size = 1, prob = pmf)
	
	out[i, ] <- c(lambda, phi, k)
}

#Summarize results
apply(out, 2, quantile, prob = c(.025, .25, .5, .75, .975))
apply(out, 2, mean)
