# Packages/applications to install for this talk

#JAGS
# Go to http://sourceforge.net/projects/mcmc-jags/files/JAGS/3.x/
# to find binary installation packages for Mac/Windows
# Go to http://mcmc-jags.sourceforge.net/ to find files related to
# Linux installation
# Install JAGS 3.1.0 or 3.2.0

# Necessary R packages

x <- c("rjags", "MCMCpack", "coda", "Rcpp", "inline", "RInside")

install.packages(x, depend = TRUE, repos="http://cran.r-project.org")

