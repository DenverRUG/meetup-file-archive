#Example:  Soft drink delivery times (Chapter 5 of Bayesian Modeling
#Using Winbugs by Ntzoufras
#
#We are interested in estimation of the required time needed by 
#each employee in a delivery system network to refill an automatic 
#vending machine.  For this reason, a small quality assurance study
#was set up by an industrial engineer of the company.  As the 
#response variable, the engineer considered the total service time 
#(measured in minutes) of each machine, including its stocking with 
#beverage products and any required maintenance or housekeeping.  
#After examining the problem, the industrial engineer recommended 
#two important variables that affect delivery time:  the number 
#of cases of stocked products and the distance walked by the 
#employee (measured in feet).  
#
#We assume that sampling distribution for the data is y_i∼N(x*beta,1/tau). 
#
#We assume information prior distributions for the regression coefficients, 
#beta_j∼N(0, 10^4) (sigmasq = 10^4) and for the precision, 
#tau∼Gamma(0.01,0.01).

library(rjags)         
library(coda)

# Read data manually
time <- c(16.68,11.5,12.03,14.88,13.75,18.11,8,17.83,79.24,21.5,40.33,21,
	13.5,19.75,24,29,15.35,19,9.5,35.1,17.9,52.32,18.75,19.83,10.75)
cases <- c(7,3,3,4,6,7,2,7,30,5,16,10,4,6,9,10,6,7,3,17,10,26,9,8,4)
distance <- c(560,220,340,80,150,330,110,210,1460,605,688,215,255,462,448,776,200,
	132,36,770,140,810,450,635,150)

n <- length(cases)

modelString = "

model {
    # Sampling distribution
    for(i in 1:n)
    {
	    y[i] ~ dnorm(mu[i], tau)
	    mu[i] <- beta0 + beta1 * cases[i] + beta2 * distance[i]
    }
    
    # Define sigmasq using precision
    sigmasq <- 1/tau
    
    # Prior distributions:
    beta0 ~ dnorm(0.0, 1.0E-4) 
    beta1 ~ dnorm(0.0, 1.0E-4) 
    beta2 ~ dnorm(0.0, 1.0E-4)
    tau ~ dgamma(0.01, 0.01)
}
"
# Write the modelString to a file, using R commands:
writeLines(modelString, con = "model.txt")

#------------------------------------------------------------------------------
# THE DATA.

# Specify the data in R, using a list format compatible with JAGS:
dataList = list(
	n = n,
    y = time,
    cases = cases,
    distance = distance
)

parameters = c("beta0", "beta1", "beta2", "sigmasq")     # The parameter(s) to be monitored.
adaptSteps = 500              # Number of steps to "tune" the samplers.
burnInSteps = 50000            # Number of steps to "burn-in" the samplers.
nChains = 3                   # Number of chains to run.
numSavedSteps=500000           # Total number of steps in chains to save.
thinSteps=1                   # Number of steps to "thin" (1=keep every step).
nIter = ceiling( ( numSavedSteps * thinSteps ) / nChains ) # Steps per chain.

# Run model 1
# Create, initialize, and adapt the model:
jagsModel = jags.model( "model.txt", data = dataList , # inits=initsList , 
                        n.chains = nChains , n.adapt = adaptSteps)
# Burn-in:
cat( "Burning in the MCMC chain...\n" )
update(jagsModel, n.iter = burnInSteps)
# The saved MCMC chain:
cat( "Sampling final MCMC chain...\n" )
codaSamples = coda.samples(jagsModel, variable.names = parameters , 
                            n.iter = nIter, thin=thinSteps )
# codaSamples is a list.  Each location in the list (codaSamples[[i]])
# contains a nsim x p matrix where nsim is the number of iterations per
# chain and p is the number of parameters being watched.
    
#------------------------------------------------------------------------------
# EXAMINE THE RESULTS.

#calculate Gelman-Rubin statistic
gelman.diag(codaSamples)

#calculate effective Sample size
effectiveSize(codaSamples)

# Convert coda-object codaSamples to matrix object for easier handling.
# But note that this concatenates the different chains into one long chain.
# Each row is an iteration of the chain and the columns are the different parameters
mcmcChain = as.matrix(codaSamples)

# posterior statistics for beta0, beta1, beta2, sigmasq
apply(mcmcChain, 2, summary)
apply(mcmcChain, 2, quantile, prob = c(.025, .975))


# 4 plots on one page
par(mfrow = c(2, 2))
#Plot densities
dbeta0 <- density(mcmcChain[,1])
plot(dbeta0, type = "l", xlab = "beta0", ylab = "density", main = "")
title("posterior density for beta0")

#Plot densities
dbeta1 <- density(mcmcChain[,2])
plot(dbeta1, type = "l", xlab = "beta1", ylab = "density", main = "")
title("posterior density for beta1")

#Plot densities
dbeta2 <- density(mcmcChain[,3])
plot(dbeta2, type = "l", xlab = "beta2", ylab = "density", main = "")
title("posterior density for beta2")

#Plot densities
dsigmasq<- density(mcmcChain[,4])
plot(dsigmasq, type = "l", xlab = "sigmasq", ylab = "density", main = "")
title("posterior density for sigmasq")

