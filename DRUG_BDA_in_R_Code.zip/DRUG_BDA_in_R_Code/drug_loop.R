# Function for gibbs sampler.  Take the number of simulations desired,
# the vector of observed data, a starting value for phi, and a starting
# value for k.

# Function takes:
# nsim: number of cycles to run
# y: vector of observed values
# a, b: prior distribution parameters for lambda
# c, d: prior distribution parameters for phi
# kposs: possible values of k
# phi, k: starting values of chain for phi and k

gibbs.loop <- function(nsim, y, a, b, c, d, kposs, phi, k)
{
	# matrix to store simulated values from each cycle
	out <- matrix(NA, nrow = nsim, ncol = 3)

	# number of observations
	n <- length(y)

	for(i in 1:nsim)
	{
		# Generate value from full conditional of phi based on
		# current values of other parameters
		lambda <- rgamma(1, a + sum(y[1:k]), b + k)
		
		# Generate value from full conditional of phi based on
		# current values of other parameters
		phi <- rgamma(1, c + sum(y[min((k+1),112):n]), d + n - k)

		# generate value of k
		# determine probability masses for full conditional of k
		# based on current parameters values
		pmf <- kprobloop(kposs, y, phi, lambda)
		k <- sample(x = kposs, size = 1, prob = pmf)
		
		out[i, ] <- c(lambda, phi, k)
	}
	out
}

# Determine vector of probabilities for full conditional 
# of k based on current values of other variables
# Takes cumulative sum of observations, phi, lambda.
# and possible values of k.  Do it using loop.

kprobloop <- function(kposs, y, phi, lambda)
{	
	#create vector to store unnormalized mass functions
	upmf <- numeric(length(kposs))

	#determine unnormalized mass functions for all possible values of k
	for(i in kposs)
	{
		upmf[i] <- exp(i*(phi - lambda)) * (lambda/phi)^sum(y[1:i])
	}
	return(upmf / sum(upmf))
}

# Read data manually 
y <- c(4,5,4,1,0,4,3,4,0,6,3,3,4,0,2,6,3,3,5,4,5,3,1,4,4,1,5,5,3,4,2,5,2,2,3,4,2,1,3,2,2,
	1,1,1,1,3,0,0,1,0,1,1,0,0,3,1,0,3,2,2,0,1,1,1,0,1,0,1,0,0,0,2,1,0,0,0,1,1,0,2,3,3,1,
	1,2,1,1,1,1,2,4,2,0,0,0,1,4,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1)

nsim <- 10000

# Run and time simulation
set.seed(1)
time1 <- system.time(chain1 <- gibbs.loop(nsim = nsim, 
	y = y, a = 4, b = 1, c = 1, d = 2, kposs = 1:112, 
	phi = 1, k = 40))
time1

#Summarize results
apply(chain1, 2, quantile, prob = c(.025, .25, .5, .75, .975))
apply(chain1, 2, mean)
