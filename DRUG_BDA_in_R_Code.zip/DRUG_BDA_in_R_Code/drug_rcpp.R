# Function for gibbs sampler.  Take the number of simulations desired,
# the vector of observed data, a starting value for phi, and a starting
# value for k.

# Function takes:
# nsim: number of cycles to run
# y: vector of observed values
# a, b: prior distribution parameters for lambda
# c, d: prior distribution parameters for phi
# kposs: possible values of k
# phi, k: starting values of chain for phi and k

library(inline)

src <- '
	//Read in and declare variables, vectors, matrices we need later
	int nsim = as<int>(nsimr);
	NumericVector y(yr);
	double a = as<double>(ar);
	double b = as<double>(br);
	double c = as<double>(cr);
	double d = as<double>(dr);
	NumericVector kposs(kpossr);
	double phi = as<double>(phir);
	double k = as<double>(kr);
	
	//Two other variables I need	
	double lambda, sumpmf; 
	NumericVector pmf(kposs.size());	
	NumericVector cusumpmf(kposs.size());	
	int i, j;
	
	// Gets random number seed from R
	RNGScope scope;

	// matrix to store simulated values from each cycle
	NumericMatrix out(nsim, 3);

	// number of observations
	int n = y.size();

	// determine sum of y and cumulative sum of y.  
	double sumy = sum(y);
	NumericVector cusum = cumsum(y);

	NumericVector u = runif(nsim, 0, 1);

	for(i = 0; i < nsim; i++)
	{
		// Generate value from full conditional of phi based on
		// current values of other parameters
		lambda = ::Rf_rgamma(a + cusum[k - 1], 1/(b + k));
		
		// Generate value from full conditional of phi based on
		// current values of other parameters
		//phi <- rgamma(1, c + sumy - cusum[k], d + 112 - k)
		phi = ::Rf_rgamma(c + sumy - cusum[k - 1], 1/(d + 112 - k));
	
		
		// generate value of k
		// pmf <- kprobvec(kposs, cusum, phi, lambda)
		for(j = 0; j < kposs.size(); j++)
		{
			pmf[j] = exp(kposs[j]*(phi - lambda)) * pow(lambda/phi, cusum[j]);
		}
	
		// determine conditional probability mass function for k	
		sumpmf = sum(pmf);
		for(j = 0; j < kposs.size(); j++)
		{
			pmf[j] = pmf[j]/sumpmf;
		}
		
		// determine cumsum of probability mass functino for k.
		// needed to sample from discrete distribution
		cusumpmf[0] = pmf[0];
		for(j = 1; j < kposs.size(); j++)
		{
			cusumpmf[j] = cusumpmf[j - 1] + pmf[j];
		}


		// sample from full conditional distribution of k
		j = 0;

		while(j < kposs.size())
		{
			if(u[i] < cusumpmf[j])
			{
				k = kposs[j];
				j = kposs.size();
			}
			j++;
		}
		
		// store values of this cycle
		out(i, 0) = lambda;
		out(i, 1) = phi;
		out(i, 2) = k;
	}

	// return results
	return out;
'

# compile c++ version of gibbs sampler
gibbs.rcpp <- cxxfunction(signature(nsimr = "int", yr = "numeric",
	ar = "numeric", br = "numeric", cr = "numeric", dr = "numeric", 
	kpossr = "numeric", phir = "numeric", kr = "numeric"), 
	src, plugin="Rcpp")

# Read data manually 
y <- c(4,5,4,1,0,4,3,4,0,6,3,3,4,0,2,6,3,3,5,4,5,3,1,4,4,1,5,5,3,4,2,5,2,2,3,4,2,1,3,2,2,
	1,1,1,1,3,0,0,1,0,1,1,0,0,3,1,0,3,2,2,0,1,1,1,0,1,0,1,0,0,0,2,1,0,0,0,1,1,0,2,3,3,1,
	1,2,1,1,1,1,2,4,2,0,0,0,1,4,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1)

nsim <- 10000

# Run and time simulation
set.seed(1)
time3 <- system.time(chain3 <- gibbs.rcpp(nsimr = nsim, 
	yr = y, ar = 4, br = 1, cr = 1, dr = 2, kpossr = 1:112, 
	phir = 1, kr = 40))
time3

#Summarize results
apply(chain3, 2, quantile, prob = c(.025, .25, .5, .75, .975))
apply(chain3, 2, mean)

time1/time3 #about 100 times faster!
time2/time3 #about 5 times faster!
