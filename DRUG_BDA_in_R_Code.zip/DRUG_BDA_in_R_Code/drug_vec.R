# Function for gibbs sampler.  Take the number of simulations desired,
# the vector of observed data, a starting value for phi, and a starting
# value for k.

# Function takes:
# nsim: number of cycles to run
# y: vector of observed values
# a, b: prior distribution parameters for lambda
# c, d: prior distribution parameters for phi
# kposs: possible values of k
# phi, k: starting values of chain for phi and k

gibbs.vec <- function(nsim, y, a, b, c, d, kposs, phi, k)
{
	# matrix to store simualted values from each cycle
	out <- matrix(NA, nrow = nsim, ncol = 3)

	# determine number of observations
	n <- length(y)

	# determine sum of y and cumulative sum of y.  
	# Then cusum[k] == sum(y[1:k])
	# and sum(y[(k+1):112]) == sumy - cusum[k]
	sumy <- sum(y)
	cusum <- cumsum(y)

	for(i in 1:nsim)
	{
		# Generate value from full conditional of phi based on
		# current values of other parameters
		lambda <- rgamma(1, a + cusum[k], b + k)
		
		# Generate value from full conditional of phi based on
		# current values of other parameters
		phi <- rgamma(1, c + sumy - cusum[k], d + n - k)
		
		# generate value of k
		pmf <- kprobvec(kposs, cusum, phi, lambda)
		k <- sample(x = kposs, size = 1, prob = pmf)
		
		out[i, ] <- c(lambda, phi, k)
	}
	out
}

# Determine vector of probabilities for full conditional 
# of k based on current values of other variables
# Takes cumulative sum of observations, phi, lambda.
# and possible values of k.  Do it using vectors.

kprobvec <- function(kposs, cusum, phi, lambda)
{
	#determine unnormalized mass functions
	upmf <- exp(kposs*(phi - lambda)) * 
		(lambda/phi)^cusum
	return(upmf / sum(upmf))
}


# Read data manually 
y <- c(4,5,4,1,0,4,3,4,0,6,3,3,4,0,2,6,3,3,5,4,5,3,1,4,4,1,5,5,3,4,2,5,2,2,3,4,2,1,3,2,2,
	1,1,1,1,3,0,0,1,0,1,1,0,0,3,1,0,3,2,2,0,1,1,1,0,1,0,1,0,0,0,2,1,0,0,0,1,1,0,2,3,3,1,
	1,2,1,1,1,1,2,4,2,0,0,0,1,4,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1)

nsim <- 10000

#run and time simulations
set.seed(1)
time2 <- system.time(chain2 <- gibbs.vec(nsim = nsim, 
	y = y, a = 4, b = 1, c = 1, d = 2, kposs = 1:112, 
	phi = 1, k = 40))

# compare results for first and second simulations
range(chain1 - chain2)

#summarize results
apply(chain2, 2, quantile, prob = c(.025, .25, .5, .75, .975))
apply(chain2, 2, mean)
