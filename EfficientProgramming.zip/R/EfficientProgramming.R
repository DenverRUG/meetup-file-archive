### R code from vignette source './Rnw/EfficientProgramming.Rnw'
### Encoding: UTF-8

