### R code from vignette source './Rnw/apply.Rnw'

###################################################
### code chunk number 1: create an example data frame and find row means using for loop
###################################################
n <- 7500
set.seed(42)
var.1 <- rnorm(n)
var.2 <- rexp(n)
var.3 <- runif(n)
var.4 <- var.2 * var.3 * var.1
eg.data <- data.frame(var.1, var.2, var.3, var.4)


###################################################
### code chunk number 2: row means via for loop
###################################################
for.time <- system.time({
  row.means <- NULL
  for(i in 1:n){
    # row.means[i] <- mean(eg.data[i, ]) # This fails.  
    row.means[i] <- mean(as.matrix(eg.data[i,]))
  }

})
head(row.means, 4)


###################################################
### code chunk number 3: row means via apply
###################################################
row.means <- NULL
row.means 
apply.time <- system.time({
  row.means <- apply(eg.data, 1, mean)
})
 
head(row.means, 4)


###################################################
### code chunk number 4: row means using base functions
###################################################
row.means <- NULL
row.means
rowMean.time <- system.time({
  row.means <- rowMeans(eg.data)
})
head(row.means, 4)


###################################################
### code chunk number 5: row mean example computational times
###################################################
for.time
apply.time
rowMean.time


###################################################
### code chunk number 6: bmi example data
###################################################
age      <- round(runif(n, 30, 60), 1)
sex      <- factor(sample(c("Male", "Female"), n, replace = TRUE))
height   <- round(rnorm(n, 67, 7), 2)
weight.0 <- round(rnorm(n, 185, 60), 2)
weight.1 <- round(rnorm(n, 150, 40), 2)

bmi.data.frame <- data.frame(age, sex, height, weight.0, weight.1)
head(bmi.data.frame)


###################################################
### code chunk number 7: bmi for loop 1
###################################################
for.time.1 <- system.time({ 
  bmi.0.via.for.1 <- NULL
  for(i in 1:n){
    bmi.0.via.for.1[i] <- bmi.data.frame[i, 'weight.0'] * 0.45359237 * 
                          (bmi.data.frame[i, 'height'] * 0.0254)^(-2)
  }
})
head(cbind(bmi.data.frame, bmi.0.via.for.1), 4)


###################################################
### code chunk number 8: bmi for loop 3
###################################################
for.time.3 <- system.time({ 
  bmi.0.via.for.3 <- NULL
  for(i in 1:n){
    wt <- bmi.data.frame[i, 'weight.0']
    ht <- bmi.data.frame[i, 'height']
    bmi.0.via.for.3[i] <- wt * 0.45359237 * (ht * 0.0254)^(-2)
  }
})
head(cbind(bmi.data.frame, bmi.0.via.for.3), 4)


###################################################
### code chunk number 9: bmi apply function
###################################################
bmi <- function(x, wt, ht){
    x[wt] * 0.45359237 * (x[ht] * 0.0254)^(-2)
}

bmi(bmi.data.frame[1, ], 'weight.0', 'height')

bmi <- function(x, wt, ht){
    x[[wt]] * 0.45359237 * (x[[ht]] * 0.0254)^(-2)
}

bmi(bmi.data.frame[1, ], 'weight.0', 'height')


###################################################
### code chunk number 10: bmi applied to the data frame
###################################################
apply.time.1 <- system.time({
 bmi.0.via.apply.1 <- 
   apply(bmi.data.frame[, !(names(bmi.data.frame) %in% 'sex')], 
         1, bmi, 
         ht = 'height', wt = 'weight.0')
})

head(cbind(bmi.data.frame, 
           bmi.0.a = bmi.0.via.apply.1, 
           bmi.0.f = bmi.0.via.for.1))


###################################################
### code chunk number 11: bmi applied to the data frame
###################################################
apply.time.2 <- system.time({
 bmi.0.via.apply.2 <- 
   apply(bmi.data.frame[, c('height', 'weight.0')], 
         1, bmi, 
         ht = 'height', wt = 'weight.0')
})

head(cbind(bmi.data.frame, 
           bmi.0.a.1 = bmi.0.via.apply.1, 
           bmi.0.a.2 = bmi.0.via.apply.2))


###################################################
### code chunk number 12: time for bmi required
###################################################
for.time.1
for.time.3
apply.time.1
apply.time.2


