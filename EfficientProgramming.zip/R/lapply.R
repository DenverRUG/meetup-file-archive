### R code from vignette source './Rnw/lapply.Rnw'

###################################################
### code chunk number 1: bmi with lapply
###################################################
is.list(bmi.data.frame)
str(as.list(bmi.data.frame[1:5, ]))


###################################################
### code chunk number 2: bmi data as a list
###################################################
str(split(bmi.data.frame[1:2, ], f = 1:2))
bmi.data.list <- split(bmi.data.frame, f = 1:nrow(bmi.data.frame))


###################################################
### code chunk number 3: bmi lapply
###################################################
bmi.0.list <- lapply(bmi.data.list, bmi, wt = 'weight.0', ht = 'height')
str(bmi.0.list[1:5])


###################################################
### code chunk number 4: bind results
###################################################
head(cbind(bmi.data.frame, bmi.0 = unlist(bmi.0.list)), 4)


###################################################
### code chunk number 5: example data set
###################################################
# example data set
onlow <- data.frame(counts     = c(1, 0, 3, 4, 6, 9, 0, 1, 2, 5, 0, 1, 7), 
                    new.series = c(0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1))
t(onlow)


###################################################
### code chunk number 6: tjs solution
###################################################
q=onlow
a=0;b=1;n=length(q[,1])
x1=list();test=c()
for(i in 1:n){
     if(q[i,2] >= 1) {a=a+1}
     if(q[i,2] >= 1) {b=1}
     if(q[i,2] >= 1) {x1[[a]]=test}
     if(q[i,2] >= 1) {test=c()}
     test[b] = q[i,1]
     b=b+1
}


###################################################
### code chunk number 7: tjs results
###################################################
x1
test


###################################################
### code chunk number 8: my solution
###################################################
# total number of observations
n <- dim(onlow)[1]

# find the index of rows where the new series starts
idx <- c(1, which(onlow[, 2] == 1), n+1)
sets <- length(idx) - 1

# collect the sets of indices for subsetting
set.idx <- mapply(function(x, y){x:y}, x = idx[-(sets+1)], y = (idx[-1]-1))

onlow.counts <- lapply(set.idx, function(x){onlow$counts[x]})


###################################################
### code chunk number 9: my solutions results
###################################################
# view the results
str(onlow.counts)


###################################################
### code chunk number 10: example big data for tj example
###################################################
n <- 50000
p <- c(0.3, 0.2, 0.1, 0.05, 0.05, 0.025, 0.05, 0.025, 0.1, 0.1)
onlow <- data.frame(counts = sample(0:9, size = n, replace = TRUE, prob = p),
                   new.series = rbinom(n, 1, p = 0.33))


###################################################
### code chunk number 11: big time tjs
###################################################
system.time({
q=onlow
a=0;b=1;n=length(q[,1])
x1=list();test=c()
for(i in 1:n){
     if(q[i,2] >= 1) {a=a+1}
     if(q[i,2] >= 1) {b=1}
     if(q[i,2] >= 1) {x1[[a]]=test}
     if(q[i,2] >= 1) {test=c()}
     test[b] = q[i,1]
     b=b+1
}
})


###################################################
### code chunk number 12: tjs one if time
###################################################
system.time({
q=onlow
a=0;b=1;n=length(q[,1])
x1=list();test=c()
for(i in 1:n){
     if(q[i,2] >= 1) {
       a=a+1
       b=1
       x1[[a]]=test
       test=c()
     }
     test[b] = q[i,1]
     b=b+1
}
}) # end system time


###################################################
### code chunk number 13: big time my solution
###################################################
system.time({
# total number of observations
n <- dim(onlow)[1]

# find the index of rows where the new series starts
idx <- c(1, which(onlow[, 2] == 1), n+1)
sets <- length(idx) - 1

# collect the sets of indices for subsetting
set.idx <- mapply(function(x, y){x:y}, x = idx[-(sets+1)], y = (idx[-1]-1))

onlow.counts <- lapply(set.idx, function(x){onlow$counts[x]})
})


