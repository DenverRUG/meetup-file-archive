### R code from vignette source './Rnw/mapply.Rnw'

###################################################
### code chunk number 1: mapply example
###################################################
foo <- function(x, y, z, w){
  return(x/y + z^w)
}
mapply(foo, x = 1:2, y = seq(2, 4, length = 6), z = 3, w = c(-1, 1))
foo(1, 2, 3, -1)
foo(2, 2.4, 3, 1)
foo(1, 2.8, 3, -1)


###################################################
### code chunk number 2: sapply example
###################################################
letters[1:3]
lapply(letters[1:3], toupper)
unlist(lapply(letters[1:3], toupper))
sapply(letters[1:3], toupper)


###################################################
### code chunk number 3: by example
###################################################
with(bmi.data.frame, by(weight.0, sex, mean))


