### R code from vignette source './Rnw/multithreading.Rnw'

###################################################
### code chunk number 1: one roc plot
###################################################
source('./R/roc.R')
load('./data/titanic.RData')




###################################################
### code chunk number 2: One ROC plot
###################################################
formula(model.7)
system.time({idx <- sample.int(dim(titanic.df)[1], 0.70 * dim(titanic.df)[1])
roc.eg <- roc(formula(model.7), 
              data = titanic.df[idx, ], 
              testing.data = titanic.df[-idx, ])
})
roc.eg$testing.auc
roc.eg$validation.auc
ggsave(roc.eg$plot, filename = './images/roc.jpeg')


###################################################
### code chunk number 3: titanic for loop
###################################################
sims <- 200
for.time <- system.time({
  results <- NULL
  for(i in 1:sims){
    idx <- sample.int(dim(titanic.df)[1], 0.70 * dim(titanic.df)[1])
    roc.4 <- roc(formula(model.4),
                 data = titanic.df[idx, ], 
                 testing.data = titanic.df[-idx, ])
    roc.6 <- roc(formula(model.6),
                 data = titanic.df[idx, ], 
                 testing.data = titanic.df[-idx, ])
    roc.7 <- roc(formula(model.7),
                 data = titanic.df[idx, ], 
                 testing.data = titanic.df[-idx, ])
    results <- rbind(results, c(t.4 = roc.4$testing.auc, 
                                t.6 = roc.6$testing.auc, 
                                t.7 = roc.7$testing.auc))
  }
})
results <- as.data.frame(results)
head(results)
gg <- ggplot(melt(results), aes(x = value, color = variable, fill = variable)) 
gg <- gg + geom_density(alpha = 0.75)
ggsave(gg, filename = './images/aucFOR.jpeg')


###################################################
### code chunk number 4: multithreading.Rnw:111-112
###################################################
for.time


###################################################
### code chunk number 5: titanic lapply
###################################################
lapply.time <- system.time({
  foo <- function(x){sample.int(dim(titanic.df)[1], 0.70 * dim(titanic.df)[1])}
  idx <- lapply(1:sims, foo)
  goo <- function(x){
  roc.4 <- roc(formula(model.4),
               data = titanic.df[x, ], 
               testing.data = titanic.df[-x, ])
  roc.6 <- roc(formula(model.6),
               data = titanic.df[x, ], 
               testing.data = titanic.df[-x, ])
  roc.7 <- roc(formula(model.7),
               data = titanic.df[x, ], 
               testing.data = titanic.df[-x, ])
  return(data.frame(t.4 = roc.4$testing.auc,
                    t.6 = roc.6$testing.auc,
                    t.7 = roc.7$testing.auc))
  }
  results <- lapply(idx, goo)
  results <- do.call(rbind, results)
})
head(results)
gg <- ggplot(melt(results), aes(x = value, color = variable, fill = variable)) 
gg <- gg + geom_density(alpha = 0.75)
ggsave(gg, filename = './images/aucLAPPLY.jpeg')


###################################################
### code chunk number 6: multithreading.Rnw:156-157
###################################################
lapply.time


###################################################
### code chunk number 7: titanic mclapply
###################################################
library(multicore)
mclapply.time <- system.time({
  foo <- function(x){sample.int(dim(titanic.df)[1], 0.70 * dim(titanic.df)[1])}
  idx <- mclapply(1:sims, foo)
  goo <- function(x){
  roc.4 <- roc(formula(model.4),
               data = titanic.df[x, ], 
               testing.data = titanic.df[-x, ])
  roc.6 <- roc(formula(model.6),
               data = titanic.df[x, ], 
               testing.data = titanic.df[-x, ])
  roc.7 <- roc(formula(model.7),
               data = titanic.df[x, ], 
               testing.data = titanic.df[-x, ])
  return(data.frame(t.4 = roc.4$testing.auc,
                    t.6 = roc.6$testing.auc,
                    t.7 = roc.7$testing.auc))
  }
  results <- mclapply(idx, goo)
  results <- do.call(rbind, results)
})
head(results)
gg <- ggplot(melt(results), aes(x = value, color = variable, fill = variable)) 
gg <- gg + geom_density(alpha = 0.75)
ggsave(gg, filename = './images/aucMCLAPPLY.jpeg')


###################################################
### code chunk number 8: multithreading.Rnw:202-203
###################################################
mclapply.time


###################################################
### code chunk number 9: titanic foreach
###################################################
library(foreach)
library(doMC)
registerDoMC(cores = 4)

foreach.time <- system.time({
  results <- NULL
  results <- foreach(i=1:sims, .combine = rbind) %dopar% {
    idx <- sample.int(dim(titanic.df)[1], 0.70 * dim(titanic.df)[1])
    roc.4 <- roc(formula(model.4),
                 data = titanic.df[idx, ], 
                 testing.data = titanic.df[-idx, ])
    roc.6 <- roc(formula(model.6),
                 data = titanic.df[idx, ], 
                 testing.data = titanic.df[-idx, ])
    roc.7 <- roc(formula(model.7),
                 data = titanic.df[idx, ], 
                 testing.data = titanic.df[-idx, ])
    c(t.4 = roc.4$testing.auc, 
      t.6 = roc.6$testing.auc, 
      t.7 = roc.7$testing.auc)
  }
})
results <- as.data.frame(results)
head(results)
gg <- ggplot(melt(results), aes(x = value, color = variable, fill = variable)) 
gg <- gg + geom_density(alpha = 0.75)
ggsave(gg, filename = './images/aucFOREACH.jpeg')


###################################################
### code chunk number 10: multithreading.Rnw:255-256
###################################################
foreach.time


###################################################
### code chunk number 11: titanic times
###################################################
for.time
lapply.time
mclapply.time
foreach.time


