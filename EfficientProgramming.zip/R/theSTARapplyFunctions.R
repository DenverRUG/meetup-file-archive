### R code from vignette source './Rnw/theSTARapplyFunctions.Rnw'

