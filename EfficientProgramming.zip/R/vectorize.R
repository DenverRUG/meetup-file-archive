### R code from vignette source './Rnw/vectorize.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: non vector
###################################################
x.1 <- 3
x.2 <- 4
x.3 <- pi
x.4 <- exp(1)


###################################################
### code chunk number 2: vector
###################################################
x <- c(3, 4, pi, exp(1))


###################################################
### code chunk number 3: vector
###################################################
x <- runif(20, 0, 10)
y <- 3 + 2 * x + rnorm(20, sd = 0.1)
lm(y ~ x)


###################################################
### code chunk number 4: build Titanic data set
###################################################
str(Titanic)


###################################################
### code chunk number 5: show the data set
###################################################
ftable(Titanic)


###################################################
### code chunk number 6: slow titanic df
###################################################
time.1 <- system.time({
titanic.df <- data.frame(class = NA, sex = NA, age = NA, survived = NA)
for(CLASS in dimnames(Titanic)$Class){
  for(SEX in dimnames(Titanic)$Sex){
    for(AGE in dimnames(Titanic)$Age){
      for(SURVIVED in dimnames(Titanic)$Survived){
        persons <- Titanic[CLASS, SEX, AGE, SURVIVED]
        if (persons > 0){
          for(i in 1:persons){
            titanic.df <- rbind(titanic.df, 
                                data.frame(class = CLASS, 
                                           sex = SEX, 
                                           age = AGE, 
                                           survived = SURVIVED))
          }
        } # end if
      }
    }
  }
}
titanic.df <- titanic.df[-1, ]
})


###################################################
### code chunk number 7: show the process worked
###################################################
str(Titanic)
str(titanic.df)
time.1


###################################################
### code chunk number 8: ftable titanic
###################################################
ftable(xtabs( ~ class + sex + age + survived, data = titanic.df))


###################################################
### code chunk number 9: fast titanic df
###################################################
head(as.data.frame(Titanic))
time.2 <- system.time({
  titanic.df <- as.data.frame(Titanic)
  titanic.df <- titanic.df[rep(rownames(titanic.df), titanic.df$Freq), 1:4]
})
str(titanic.df)
head(titanic.df)
time.2


###################################################
### code chunk number 10: model defs to display
###################################################
model.1 <- glm(Survived ~ Class, 
               data = titanic.df, 
               subset = !(Class %in% 'Crew'),
               family = 'binomial')
model.2 <- update(model.1, formula = . ~ Sex)
model.3 <- update(model.1, formula = . ~ Age)
model.4 <- update(model.1, formula = . ~ Class + Sex)
model.5 <- update(model.1, formula = . ~ Class + Age)
model.6 <- update(model.1, formula = . ~ Sex + Age)
model.7 <- update(model.1, formula = . ~ Class + Sex + Age)
save(titanic.df, model.1, model.2, model.3, model.4, model.5, model.6, model.7,
     file = './data/titanic.RData')


###################################################
### code chunk number 11: summary of model1
###################################################
print(xtable(summary(model.1)), floating = FALSE)


###################################################
### code chunk number 12: summary of model7
###################################################
print(xtable(summary(model.7)), floating = FALSE)


