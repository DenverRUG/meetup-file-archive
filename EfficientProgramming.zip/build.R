###
### file: build.R
###
### build efficient programming presentation
###
library(ggplot2)
library(xtable)

rm(list = objects())

rnw.files <- dir('./Rnw')
rnw.files <- rnw.files[sapply(strsplit(rnw.files, '.Rnw'), length) == 1]
rnw.files <- gsub('.Rnw', '', rnw.files)

sweaving <- function(x){
  cat('\n\n', rep('=', 39), '\nWorking on file:', x, '\n\n')

  Stangle(file = paste('./Rnw/', x, '.Rnw', sep = ''),
          out  = paste('./R/',   x, '.R',   sep = ''))

  Sweave(file  = paste('./Rnw/', x, '.Rnw', sep = ''),
         out   = paste('./tex/', x, '.tex', sep = ''),
         engine = "R") #, echo = 'FALSE', results = 'hide')
}

sapply(rnw.files, sweaving)

tools::texi2dvi(file = "./tex/EfficientProgramming.tex",
                pdf  = TRUE,
                clean = TRUE,
                quiet = TRUE)
