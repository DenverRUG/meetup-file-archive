# R-sources.R

require(bibtex)
write_bib(x = .packages(all.available = TRUE), file = "~/LaTeX/R-sources.bib")

