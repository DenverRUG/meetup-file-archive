################################################################################
### file:   build.R
### author: Peter DeWitt
###
### For: BASIC BUILD FILE TO BE COPIED INTO EACH NEW PROJECT.
###
### set your working directory in R to 
### setwd("./RCL/_____")
###
### Please try to follow the Google R Style Guide.
### http://google-styleguide.googlecode.com/svn/trunk/google-r-style.html
###
### This file should be do the following:
###  0) Library Loads for the project.  
###  1) Remove (delete) all objects so that during compile there is no error
###     resulting from carry over in developement
###  2) Define constants for the project, such as digits to display and 
###     the alpha value
###
### To use this file in vim use type <LocalLeader>sm which will call this script 
### and then run knitall() and compile()
################################################################################   

################################################################################
### LIBRARY LOADS - librarys specific for this project not loaded in 
###                 your Rprofile.site file
################################################################################

################################################################################
### Remove all objects from the R session and define constants, load custom
### functions here as well.
###
################################################################################
rm(list = objects())

# load("./data/.RData") # load the datasets for the project

kAlpha   <- 0.05  # significance level for the project.
kLevel   <- 1 - kAlpha
kDigits  <- 3     # digits for printing point estimates
kPDigits <- 4     # digits for printing p-values


# frmt is a wrapper for the formatC call to control the format of numbers.  
# this will force the number of digits on the right side of a decimal point
# to be displayed, even if the digits are zeros
frmt <- function(x, digits = kDigits){
  formatC(x, digits = digits, format = "f")
}

# frmtp will format numbers, ideally p-values to digits long.  If the p-value
# is less than 0.1^digits then the return is, for example with digits = 4,
# " < 0.0001"
frmtp <- function(x, digits = kPDigits){
  out <- matrix(NA, nrow = length(x), ncol = 1)
  for(i in 1:length(x)){
    if (x[i] >= 0.1^(digits)){
      out[i, ] <- formatC(x[i], digits = digits, format = "f")
    }
    else
    {
      out[i, ] <- paste("<", frmt(0.1^(digits), digits))
    }
  }
  return(out)
}

################################################################################
### knitr 
### Dig into the ./Rnw directory and list all files with a .Rnw extension
### and run knitr() outputing .R files to the ./R directory and
### .tex files to the ./tex directory
###
### Compile of the files will be done by default in alphabetical order.
###
### There are other options, such as using child files, but this method works
### well for the file structure I am using
################################################################################
rnw.files <- dir('./Rnw')
rnw.files <- rnw.files[sapply(strsplit(rnw.files, '.Rnw'), length) == 1]
rnw.files <- gsub('.Rnw', '', rnw.files)

opts_chunk$set(fig.path  = "images/",
               #out.width = "0.48\\textwidth", #perhaps better at each chunk?
               fig.align = "center",
               dev       = "png",
               tidy      = FALSE,
               echo      = FALSE,
               results   = "hide")

knitone <- function(x){
        knit(input  = paste("./Rnw/", x, ".Rnw", sep = ""),
             output = paste("./tex/", x, ".tex", sep = ""),
             tangle = FALSE)
        knit(input  = paste("./Rnw/", x, ".Rnw", sep = ""),
             output = paste("./R/",   x, ".R", sep = ""),
             tangle = TRUE)

}

knitall <- function(){sapply(rnw.files, knitone)}

################################################################################
### compile the LaTeX to pdf and place the resulting file in the working 
### directory.
###
################################################################################
compile <- function(){
#  if (.Platform$OS != 'windows'){
#    system("pdflatex ./tex/MAIN.tex 
#            bibtex MAIN.aux
#            pdflatex ./tex/MAIN.tex 
#            pdflatex ./tex/MAIN.tex")
#  } else {
#    tools::texi2dvi(file  = "./tex/MAIN.tex",
#                    pdf   = TRUE,
#                    clean = FALSE,
#                    quiet = FALSE)
#  }
    system("pdflatex ./tex/MAIN.tex 
            bibtex MAIN.aux
            pdflatex ./tex/MAIN.tex 
            pdflatex ./tex/MAIN.tex")
}

################################################################################
### End of File ### ### End of File ###  ### End of File ### ### End of File ###
################################################################################
