## @knitr compile_time
cat("% knitted", date(), "\n\n")


