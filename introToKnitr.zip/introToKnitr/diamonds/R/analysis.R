## @knitr compile_time
cat("% knitted", date(), "\n\n")


## @knitr summary_table
tabHeader(response = "cut",
          dat      = diam,
          caption  = "Summary of the Diamond Data set used for the presentation of \\texttt{knitr}, R, and \\LaTeX.  The reported values are either the counts and row percentages for categorical values or mean and standard deviation for continuous variables.  The reported p-values are from $a$: ANOVA, $c$: chi square test, or $f$ Fisher Exact Test.",
          label    = "tab:data_summary")
tabMean(response = "cut", pred = "carat",   dat = diam, label = "Carat")
tabCat( response = "cut", pred = "color",   dat = diam, label = "Color")
tabCat( response = "cut", pred = "clarity", dat = diam, label = "Cut")
tabMean(response = "cut", pred = "depth",   dat = diam, label = "Depth")
tabMean(response = "cut", pred = "table",   dat = diam, label = "Table")
tabMean(response = "cut", pred = "price",   dat = diam, label = "Price")


