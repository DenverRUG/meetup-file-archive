
## @knitr model_fitting
# This code is not evaluated during knitting, it serves as a record of the 
# model fitting process
fit <- lm(price ~ carat * cut + clarity, data = diam)
# fit <- lm(price ~ carat * cut, data = diam)
# fit <- update(fit, formula = log(price) ~ .)
fit <- update(fit, formula = sqrt(price) ~ .)
# fit <- lm(price ~ carat^2 + carat + cut + clarity, data = diam)
plot(fit)
plot(rstudent(fit))
plot(fit$fitted, rstudent(fit))
qqnorm(rstudent(fit)); qqline(rstudent(fit))

dat <- expand.grid(clarity = levels(diam$clarity),
                   cut     = levels(diam$cut))

# added the carat for the diamonds within the observed range for cut & clarity
crt <- apply(dat, 1, 
             function(x){
               idx <- which(diam$clarity %in% x["clarity"] & 
                            diam$cut %in% x["cut"])
               with(diam[idx, ], range(carat))
             })
dat <- lapply(1:nrow(dat), 
              function(idx){
                carat <- seq(crt[1, idx], crt[2, idx], by = 0.05)
                cbind(dat[rep(idx, length(carat)), ], carat)
              })
dat <- do.call(rbind, dat)

temp <- predict(fit, newdata = dat, se.fit = TRUE, interval = "confidence")
dat <- cbind(dat, temp$fit)


ggplot(diam) + 
# aes(x = carat, y = log(price)) + 
# aes(x = carat, y = sqrt(price)) + 
aes(x = carat, y = price) + 
  geom_point() + 
  #   facet_wrap( ~ cut) + 
  facet_grid(cut ~ clarity) + 
  #   geom_line(data = dat, aes(y = fit)) + 
  #   geom_ribbon(data = dat, aes(ymin = lwr, y = fit, ymax = upr), color = 'red')
  geom_ribbon(data = dat, aes(ymin = lwr**2, y = fit**2, ymax = upr**2), color = 'red')


## @knitr anova
fit <- lm(sqrt(price) ~ carat * cut + clarity, data = diam)
rtn <- data.frame(anova(fit))
rtn[1:4, 5] <- frmtp(rtn[1:4, 5])
names(rtn) <- c("DF", "SS", "MS", "F-value", "pvalue")
print(xtable(rtn,
             digits = 0,
             align = "lrrrrr",
             caption = "ANOVA table for the modeling the square root of the price of diamonds on the carat, cut, and clarity.",
             label = "tab:anova"),
      caption.placement = "top")


## @knitr parameters
rtn <- data.frame(summary(fit)$coef)

rownames(rtn) <- gsub("cut", "cut = ", rownames(rtn))
rownames(rtn) <- gsub("clarity", "clarity = ", rownames(rtn))
names(rtn)[4] <- "pvalue"
rtn$pvalue <- frmtp(rtn$pvalue)

print(xtable(rtn,
             digits = kDigits,
             align = "lrrrr",
             caption = "Parameter estimates for the model of the square root of the diamond price on the cut, clarity, and carat.",
             label = "tab:parameters"),
      caption.placement = "top")


## @knitr price
# create a data set to plot the fitted values
dat <- expand.grid(clarity = levels(diam$clarity),
                   cut     = levels(diam$cut))

# added the carat for the diamonds within the observed range for cut & clarity
crt <- apply(dat, 1, 
             function(x){
               idx <- which(diam$clarity %in% x["clarity"] & 
                            diam$cut %in% x["cut"])
               with(diam[idx, ], range(carat))
             })
dat <- lapply(1:nrow(dat), 
              function(idx){
                carat <- seq(crt[1, idx], crt[2, idx], by = 0.05)
                cbind(dat[rep(idx, length(carat)), ], carat)
              })
dat <- do.call(rbind, dat)

temp <- predict(fit, newdata = dat, se.fit = TRUE, interval = "confidence")
dat <- cbind(dat, temp$fit)

ggplot(diam) + 
  aes(x = carat, y = price) + 
  geom_point() + 
  facet_grid(cut ~ clarity) + 
  geom_ribbon(data = dat, aes(ymin = lwr^2, y = fit^2, ymax = upr^2), 
              color = 'red')


