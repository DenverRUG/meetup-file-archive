################################################################################
### file:   build.R
### author: Peter DeWitt
###
### For: BASIC BUILD FILE TO BE COPIED INTO EACH NEW PROJECT.
###
### set your working directory in R to 
### setwd("./RCL/_____")
###
### Please try to follow the Google R Style Guide.
### http://google-styleguide.googlecode.com/svn/trunk/google-r-style.html
###
### This file should be do the following:
###  0) Library Loads for the project.  
###  1) Remove (delete) all objects so that during compile there is no error
###     resulting from carry over in developement
###  2) Define constants for the project, such as digits to display and 
###     the alpha value
###
### To use this file in vim use type <LocalLeader>sm which will call this script 
### and then run knitall() and compile()
################################################################################   

################################################################################
### LIBRARY LOADS - librarys specific for this project not loaded in 
###                 your Rprofile.site file
################################################################################

# for the sake of the example the librarys needed to build this report are 
# loaded here such that the report can be build using R --vanilla
library(ggplot2)
library(knitr)
library(xtable)

################################################################################
### Remove all objects from the R session and define constants, load custom
### functions here as well.
###
################################################################################
rm(list = objects())

load("./data/diam.RData") # load the datasets for the project

kAlpha   <- 0.05  # significance level for the project.
kLevel   <- 1 - kAlpha
kDigits  <- 3     # digits for printing point estimates
kPDigits <- 4     # digits for printing p-values


# frmt is a wrapper for the formatC call to control the format of numbers.  
# this will force the number of digits on the right side of a decimal point
# to be displayed, even if the digits are zeros
frmt <- function(x, digits = kDigits){
  formatC(x, digits = digits, format = "f")
}

# frmtp will format numbers, ideally p-values to digits long.  If the p-value
# is less than 0.1^digits then the return is, for example with digits = 4,
# " < 0.0001"
frmtp <- function(x, digits = kPDigits){
  out <- matrix(NA, nrow = length(x), ncol = 1)
  for(i in 1:length(x)){
    if (x[i] >= 0.1^(digits)){
      out[i, ] <- formatC(x[i], digits = digits, format = "f")
    }
    else
    {
      out[i, ] <- paste("<", frmt(0.1^(digits), digits))
    }
  }
  return(out)
}

# Function for building the summary tables,
# three functions tabCat for categorical variables
# tabMean for continuous variables
# tabHeader for the setup of the longtable header
tabCat <- function(response, pred, dat, label){
  #   pred <- predictors2[2]
  #   label <- predictors.names[2]
  tabn <- xtabs( ~ dat[, pred] + droplevels(dat[, response]))
  tabp <- paste(frmt(prop.table(tabn, margin = 1) * 100, 1), "\\%", sep = "")

  rtn <- matrix(NA, ncol = ncol(tabn) * 2 + 1, nrow = nrow(tabn))

  rtn[, seq(1, ncol(rtn) - 1, by = 2)] <- tabn
  rtn[, seq(2, ncol(rtn) - 1, by = 2)] <- tabp

  rownames(rtn) <- paste(rownames(tabn), "n =", rowSums(tabn))

  suppressWarnings(test <- chisq.test(tabn))
  if (any(test$expected < 5)) test <- fisher.test(tabn, simulate.p.value = TRUE, B = 10000)
  test.method <- ifelse(length(grep("Chi", test$method)) == 1, "c", "f")

  rtn[1, ncol(rtn)] <- paste("$", frmtp(test$p.value), "^", test.method, "$", sep = "")

  cat("\\multicolumn{", ncol = ncol(rtn) + 1, "}{l}{\\bfseries", label, "} \\\\")
  print(xtable(rtn), 
        only.contents = TRUE,
        sanitize.text = function(x){x},
        include.colnames = FALSE,
        hline.after = nrow(rtn),
        add.to.row = list(pos = list(seq(0, nrow(rtn) - 1, by = 1)),
                          command = "\\nopagebreak "))

}

tabMean <- function(response, pred, dat, label){
  #   pred <- predictors[1]
  #   label <- predictors.names[1]

  tabn <- t(aggregate(dat[, pred] ~ droplevels(dat[, response]), data = NULL, FUN = mean))
  tabp <- t(aggregate(dat[, pred] ~ droplevels(dat[, response]), data = NULL, FUN = sd))

  test <- aov(dat[, pred] ~ droplevels(dat[, response]))
  
  rtn <- matrix(NA, ncol = ncol(tabn)*2 + 1, nrow = nrow(tabn))

  rtn[, seq(1, ncol(rtn) - 1, by = 2)] <- tabn
  rtn[, seq(2, ncol(rtn) - 1, by = 2)] <- tabp

  rtn <- matrix(frmt(rtn[2, ]), nrow = 1)
  rownames(rtn) <- " "

  rtn[1, ncol(rtn)] <- paste("$", frmtp(summary(test)[[1]][1, "Pr(>F)"]), "^a$", sep = "")

  cat("\\multicolumn{", ncol = ncol(rtn) + 1, "}{l}{\\bfseries", label, "} \\\\")
  print(xtable(rtn), 
        only.contents = TRUE,
        sanitize.text = function(x){x},
        include.colnames = FALSE,
        hline.after = nrow(rtn))
}

tabHeader <- function(response, dat, caption, label){
  rsp <- droplevels(dat[, response])
  cat("\\begin{longtable}{l|", rep("rr|", nlevels(rsp)), "r}\n", sep = "")
  cat("\\caption{", caption, "} \\label{", label, "} \\\\", sep = "")

      #     header and footer info
      cat(" \\hline &")
      for(lev in levels(rsp)){
        cat("\\multicolumn{2}{c|}{\\bfseries", lev, "} & \n")
      }
      cat("\\\\ \n & ")
      for(lev in levels(rsp)){
        cat("\\multicolumn{2}{c|}{n = ", sum(rsp == lev), "} & \n")
      }
      cat("p-value \\\\ \\hline \n \\endfirsthead\n\n")

      cat("\\multicolumn{", nlevels(rsp) * 2 + 2, 
          "}{c}{\\bfseries \\tablename\\ \\thetable{} -- continued from previous page} \\\\",
          "\\hline &")
      for(lev in levels(rsp)){
        cat("\\multicolumn{2}{c|}{\\bfseries", lev, "} &\n")
      }
      cat("\\\\ \n & ")
      for(lev in levels(rsp)){
        cat("\\multicolumn{2}{c|}{n = ", sum(rsp == lev), "} & \n")
      }
      cat("p-value \\\\ \\hline \n \\endhead\n\n")

      cat("\\hline \\multicolumn{", nlevels(rsp) * 2 + 1, 
          "}{c}{Continued on next page} \\\\ \\hline \\endfoot\n\n", 
          "\\hline \\hline \\endlastfoot")
}

################################################################################
### knitr 
### Dig into the ./Rnw directory and list all files with a .Rnw extension
### and run knitr() outputing .R files to the ./R directory and
### .tex files to the ./tex directory
###
### Compile of the files will be done by default in alphabetical order.
###
### There are other options, such as using child files, but this method works
### well for the file structure I am using
################################################################################
rnw.files <- dir('./Rnw')
rnw.files <- rnw.files[sapply(strsplit(rnw.files, '.Rnw'), length) == 1]
rnw.files <- gsub('.Rnw', '', rnw.files)

opts_chunk$set(fig.path  = "images/",
               #out.width = "0.48\\textwidth", #perhaps better at each chunk?
               fig.align = "center",
               dev       = "png",
               tidy      = FALSE,
               echo      = FALSE,
               results   = "hide")

knitone <- function(x){
        knit(input  = paste("./Rnw/", x, ".Rnw", sep = ""),
             output = paste("./tex/", x, ".tex", sep = ""),
             tangle = FALSE)
        knit(input  = paste("./Rnw/", x, ".Rnw", sep = ""),
             output = paste("./R/",   x, ".R",   sep = ""),
             tangle = TRUE)

}

knitall <- function(){sapply(rnw.files, knitone)}

################################################################################
### compile the LaTeX to pdf and place the resulting file in the working 
### directory.
###
################################################################################
compile <- function(){
#  if (.Platform$OS != 'windows'){
#    system("pdflatex ./tex/MAIN.tex 
#            bibtex MAIN.aux
#            pdflatex ./tex/MAIN.tex 
#            pdflatex ./tex/MAIN.tex")
#  } else {
#    tools::texi2dvi(file  = "./tex/MAIN.tex",
#                    pdf   = TRUE,
#                    clean = FALSE,
#                    quiet = FALSE)
#  }
    system("pdflatex ./tex/MAIN.tex 
            bibtex MAIN.aux
            pdflatex ./tex/MAIN.tex 
            pdflatex ./tex/MAIN.tex")
}

################################################################################
### End of File ### ### End of File ###  ### End of File ### ### End of File ###
################################################################################
