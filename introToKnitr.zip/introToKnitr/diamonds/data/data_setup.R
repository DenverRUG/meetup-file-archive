# file:   data_setup.R
# author: Peter DeWitt
# 
# for:    create a dataset based on the diamonds data set included in the 
#         ggplot2 library
#
# run from the working directory
# ~/DRUG/introToKnitr/diamonds/
#
# change log:
#   30 June 2012 - file created to show data read with XLConnect
#
#   10 Aug 2012  - There is no real point to the XLConnect example here
#   the point is to show knitr.  The idea of a data read script to save a data
#   set in a .RData file should be sufficient
#


require(ggplot2)
# require(XLConnect) 
str(diamonds)

# get a random set of 27383 diamods from the original data set
set.seed(42)
diam <- diamonds[sample(1:nrow(diamonds), 27383), ]
diam <- subset(diam, price < 2000)

# Ordered factors are a pain.  remove the ordering
diam$cut <- factor(diam$cut, ordered = FALSE)
diam$clarity <- factor(diam$clarity, ordered = FALSE)
diam$color <- factor(diam$color, ordered = FALSE)

diam$ccc <- paste(diam$cut, diam$color, diam$clarity, sep = "-")
names(diam)

# write the data frame to a workbook to read in 
# wb <- loadWorkbook(file = "./ice.xlsx", create = TRUE)
# sht <- createSheet(wb, name = "Diamonds")
# writeWorksheet(object = wb, 
#                data = diam[, -(2:4)],
#                sheet = "Diamonds")
# saveWorkbook(wb)

# on second thought, just save the data set 
save(diam, file = "./data/diam.RData")

###############
# end of file #
###############

