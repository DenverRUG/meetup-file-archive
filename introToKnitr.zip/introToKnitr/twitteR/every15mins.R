# knit PrezTweets every 15 minutes for three hours

rm(list = ls())

for(i in 1:13){
  knit(input = "PrezTweets.Rhtml",
       output = paste("PrezTweets ", date(), ".html", sep = ""))
  Sys.sleep(15 * 60)
}
